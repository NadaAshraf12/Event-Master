import { useNavigate } from "react-router-dom";
import ApiService from "./ApiService";

export function useAuthorize() {
  const navigate = useNavigate();
  const api = new ApiService('https://localhost:7024/api');

  return async (requiredRole) => {
    try {
      const authData = await api.checkAuth();
      
      if (!authData?.role) {
        throw new Error("No role found");
      }
      
      if (authData.role !== requiredRole) {
        navigate('/'); 
        throw new Error("Unauthorized");
      }
      
      return true; 
    } catch (error) {
      console.error("Authorization error:", error);
      navigate('/'); 
      throw error; 
    }
  };
}