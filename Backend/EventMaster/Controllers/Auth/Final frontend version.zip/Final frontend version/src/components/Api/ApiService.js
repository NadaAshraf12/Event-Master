import axios from "axios";
import { getCookie, setCookie } from "../CookiesFunction";
import Swal from "sweetalert2";

class ApiService {
  constructor(baseURL) {
    this.api = axios.create({
      baseURL,
      headers: {
        "Content-Type": "application/json",
      },
      withCredentials: true,
    });

    this.api.interceptors.request.use(
      (config) => {
        const userData = getCookie("userData");
        if (userData) {
          const parsedData = JSON.parse(userData);
          const token = parsedData.token;
          if (token) {
            config.headers.Authorization = `Bearer ${token}`;
          }
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    this.api.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        if (error.response && error.response.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const refreshResponse = await this.api.post('/authentication/refresh');
            const newToken = refreshResponse.data.token;

            const userData = getCookie("userData");
            if (userData) {
              const parsedData = JSON.parse(userData);
              parsedData.token = newToken;
              setCookie("userData", JSON.stringify(parsedData));
            }

            originalRequest.headers['Authorization'] = `Bearer ${newToken}`;
            return this.api(originalRequest);
          } catch (refreshError) {
            await Swal.fire({
              title: 'Session Expired',
              text: 'Your session has expired. Please login again.',
              icon: 'error',
              confirmButtonText: 'OK'
            });
            setCookie("userData", "", -1);
            window.location.href = "/login";
            return Promise.reject(refreshError);
          }
        }

        let errorMessage = 'An error occurred';
        if (error.response) {
          errorMessage = error.response.data?.message || error.response.statusText;
        } else {
          errorMessage = error.message;
        }

        await Swal.fire({
          title: 'API Error',
          text: errorMessage,
          icon: 'error',
          confirmButtonText: 'OK'
        });

        return Promise.reject(error);
      }
    );
  }

  async get(endpoint) {
    try {
      const response = await this.api.get(endpoint);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  async post(endpoint, data) {
    try {
      const response = await this.api.post(endpoint, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  async postFormData(endpoint, formData) {
    try {
      const response = await this.api.post(endpoint, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  async put(endpoint, data) {
    try {
      const response = await this.api.put(endpoint, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  async delete(endpoint) {
    try {
      const response = await this.api.delete(endpoint);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  async checkAuth() {
    try {
      const response = await this.api.get('/authentication/check-auth');
      return response.data;
    } catch (error) {
      throw error;
    }
  }
}

export default ApiService;