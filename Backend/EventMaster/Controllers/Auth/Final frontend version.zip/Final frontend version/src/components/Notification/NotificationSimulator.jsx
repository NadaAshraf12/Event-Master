import React, { useEffect, useState } from "react";
import styles from "./NotificationSimulator.module.css";

const NotificationSimulator = () => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setNotifications(prev => [
        {
          message: "🎉 New Event Added: AI Conference 2025!",
          createdAt: new Date().toISOString()
        },
        ...prev
      ]);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="row" style={{ marginTop: "20px" }}>
      <div className="col-xs-12">
        {notifications.map((n, i) => (
          <div key={i} className={styles.notificationBox}>
            <p>{n.message}</p>
            <small>{new Date(n.createdAt).toLocaleString()}</small>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NotificationSimulator;
